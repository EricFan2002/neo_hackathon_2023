package com.shashank.paymentappui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.shashank.paymentappui.databinding.FragmentHomeBinding
import kotlinx.android.synthetic.main.fragment_dashboard.*
import kotlinx.android.synthetic.main.activity_payment_success.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import okio.IOException
import org.json.JSONObject
import java.util.*


class HomeFragment : Fragment() {
    private lateinit var dataBindfr: FragmentHomeBinding
    var GAS = "0";
    var NEO = "0";

    companion object {
        @JvmStatic
        private var lastHash: String = "";
    }

    private var timer = Timer()
    lateinit var task: TimerTask;

    override fun onDetach() {
        super.onDetach()
        timer.cancel()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        timer.schedule(task,0,2000);
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dataBindfr = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_home,
            container,
            false
        )
//        Show status bar text color to black
        timer = Timer()
        task = object : TimerTask() {
            override fun run() {
                var netmanager = MainActivity2()
                netmanager.postRequest("http://149.28.138.181:20332/", "{\n" +
                        "  \"jsonrpc\": \"2.0\",\n" +
                        "  \"method\": \"getwalletbalance\",\n" +
                        "  \"params\": [\"0xef4073a0f2b305a38ec4050e4d3d28bc40ea63f5\"],\n" +
                        "  \"id\": 1\n" +
                        "}", object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
//                        NEO = "-1"
                    }

                    override fun onResponse(call: Call, response: Response) {
                        val json_obj = response.body?.string()?.let { JSONObject(it) }

                        if (json_obj != null) {
                            NEO = json_obj.getJSONObject("result").getString("balance")
                        }
                    }
                })
                netmanager.postRequest("http://149.28.138.181:20332/", "{\n" +
                        "  \"jsonrpc\": \"2.0\",\n" +
                        "  \"method\": \"getwalletbalance\",\n" +
                        "  \"params\": [\"0xd2a4cff31913016155e38e474a2c06d08be276cf\"],\n" +
                        "  \"id\": 1\n" +
                        "}", object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
//                        GAS = "-1"
                    }

                    override fun onResponse(call: Call, response: Response) {
                        val json_obj1 = response.body?.string()?.let { JSONObject(it) }
                        if (json_obj1 != null) {
                            GAS = json_obj1.getJSONObject("result").getString("balance")
                        }

                    }
                })
                try {
                    activity?.runOnUiThread(Runnable {
                        if(GAS.length >= 3)
                            dataBindfr.textView4.text =
                                "NEO " + NEO + " | GAS " + GAS[0]+GAS[1]+"."+GAS[2];
                        else if(GAS.length >= 2)
                                dataBindfr.textView4.text =
                                    "NEO " + NEO + " | GAS " + GAS[0]+GAS[1];
                    })


                }
                catch (e:Exception){
                    activity?.runOnUiThread(Runnable {
                        dataBindfr.textView4.text =
                            "ERR";
                    })
                }

                netmanager.getRequest("http://149.28.138.181:12345/get?id=NhQHRrgHhLQ74fR51N42X8LHr9EuX1fwzR",
                    object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                        }

                        override fun onResponse(call: Call, response: Response) {
                            var newHash = response.body?.string()
                            if (newHash != lastHash){
                                if (newHash != null) {
                                    lastHash = newHash
                                }
                                // update!
                                var cnt = 0
                                if (newHash != null) {
                                    for(achar in newHash){
                                        if(achar == ',') {
                                            cnt += 1
                                        }
                                    }
                                }
                                if(cnt == 1){
                                    // ok ID,AMOUNT
                                    var sep = newHash?.split(",")
                                    var tID = sep?.get(0)
                                    var tAmount = sep?.get(1)
                                        startActivity(
                                            Intent(
                                                context,
                                                PaymentSuccessActivity::class.java
                                            ).apply {
                                                // you can add values(if any) to pass to the next class or avoid using `.apply`
                                                putExtra("ID", tID)
                                                putExtra("amount", tAmount)
                                            })

                                }

                            }

                        }
                        }
                    )


            }

        }
//        timer.schedule(task,0,2000);
        return dataBindfr.root;
//        return inflater.inflate(R.layout.fragment_home, container, false)
    }

}
