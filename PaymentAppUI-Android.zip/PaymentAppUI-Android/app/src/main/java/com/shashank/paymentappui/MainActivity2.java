package com.shashank.paymentappui;

import android.os.AsyncTask;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity2  {

    OkHttpClient client;

    public MainActivity2(){
        client = new OkHttpClient();

    }

    TextView txtString;

    public String url = "https://reqres.in/api/users/2";
    public String body = "{\n" +
            "  \"jsonrpc\": \"2.0\",\n" +
            "  \"method\": \"sendtoaddress\",\n" +
            "  \"params\": [\"0xef4073a0f2b305a38ec4050e4d3d28bc40ea63f5\", \"NhQHRrgHhLQ74fR51N42X8LHr9EuX1fwzR\", 1],\n" +
            "  \"id\": 1\n" +
            "}";
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");


    void postRequest(String postUrl, String postBody, Callback callback) throws IOException {

        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(JSON, postBody);

        Request request = new Request.Builder()
                .url(postUrl)
                .post(body)
                .build();

        client.newCall(request).enqueue(callback);
    }

    void getRequest(String getUrl, Callback callback) throws IOException {

        OkHttpClient client = new OkHttpClient();

//        RequestBody body = RequestBody.create(JSON, postBody);

        Request request = new Request.Builder()
                .url(getUrl)
                .build();

        client.newCall(request).enqueue(callback);
    }
}
