package com.shashank.paymentappui;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.TextView;

import android.os.Bundle;

import java.util.Objects;

public class PaymentSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_success);
        Objects.requireNonNull(getSupportActionBar()).hide();

        String ID = getIntent().getStringExtra("ID");
        String Amount = getIntent().getStringExtra("amount");
        setContentView(R.layout.activity_payment_success);
        TextView amt = findViewById(R.id.amount);
        TextView id = findViewById(R.id.actionid);
        amt.setText("Amount: " + Amount.replaceAll("\n", "").replaceAll(" ","") + " NEO");
        id.setText("TransferID: " + ID);
    }
}