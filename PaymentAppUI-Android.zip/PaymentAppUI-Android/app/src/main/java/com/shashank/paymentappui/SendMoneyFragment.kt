package com.shashank.paymentappui

import android.app.Activity.RESULT_CANCELED
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.shashank.paymentappui.databinding.FragmentSendMoneyBinding
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import okio.IOException
import org.json.JSONObject


class SendMoneyFragment : Fragment() {

//    fun onClick(View view){
//
//    }
    private lateinit var dataBind: FragmentSendMoneyBinding
    private lateinit var netmanager : MainActivity2

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        dataBind = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_send_money,
            container,
            false
        )
        val policy = ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)


        return dataBind.root



//        return inflater.inflate(R.layout.fragment_send_money, container, false)
    }

//    fun SendGET(url: String, callback: Callback): Call {
//        val request = Request.Builder()
//            .url(url)
//            .build()
//
//        val call = client.newCall(request)
//        call.enqueue(callback)
//        return call
//    }

//    fun pushSuccess(){
//        val url = "149.28.138.181:12345/set?"
//
//        val request = Request.Builder()
//            .url(url)
//            .post(formBody)
//            .build()
//
//
//        request.GET(url, object: Callback {
//            override fun onResponse(call: Call?, response: Response) {
//                val responseData = response.body()?.string()
//                runOnUiThread{
//                    try {
//                        var json = JSONObject(responseData)
//                        println("Request Successful!!")
//                        println(json)
//                        val responseObject = json.getJSONObject("response")
//                        val docs = json.getJSONArray("docs")
//                        this@MainActivity.fetchComplete()
//                    } catch (e: JSONException) {
//                        e.printStackTrace()
//                    }
//                }
//            }
//
//            override fun onFailure(call: Call?, e: IOException?) {
//                println("Request Failure.")
//            }
//        })
//
//    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        netmanager = MainActivity2()
        dataBind.buttonconfirm?.setOnClickListener {
            activity?.runOnUiThread(Runnable {
                // call the invalidate()
                val amt = dataBind.outlinedTextField1a?.text
                val addrr = dataBind.outlinedTextField2a?.text
                val disc = dataBind.outlinedTextField3a?.text
                dataBind.buttonconfirm!!.setText("Wait...")
                netmanager.postRequest("http://149.28.138.181:20332/", "{\n" +
                        "  \"jsonrpc\": \"2.0\",\n" +
                        "  \"method\": \"sendtoaddress\",\n" +
                        "  \"params\": [\"0xef4073a0f2b305a38ec4050e4d3d28bc40ea63f5\", \"" + addrr + "\", "+ amt + "],\n" +
                        "  \"id\": 1\n" +
                        "}", object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        activity?.runOnUiThread(Runnable {
                            // call the invalidate()
                            dataBind.buttonconfirm!!.setText(e.message)
                        })

                    }

                    override fun onResponse(call: Call, response: Response) {
                        activity?.runOnUiThread(Runnable {
                            // call the invalidate()
                            dataBind.buttonconfirm!!.setText(response.message)

                        })
                        val json_obj = response.body?.string()?.let { JSONObject(it) }

                        if (json_obj != null) {
                            var res = json_obj.getJSONObject("result").getString("hash")
                            netmanager.getRequest("http://149.28.138.181:12345/set?id="+addrr+"&hash=" + res + "," + amt,
                                object : Callback {
                                    override fun onFailure(call: Call, e: IOException) {
                                        activity?.runOnUiThread(Runnable {
                                            // call the invalidate()
                                        })

                                    }
                                    override fun onResponse(call: Call, response: Response) {
                                        activity?.runOnUiThread(Runnable {
                                            // call the invalidate()
                                            dataBind.buttonconfirm!!.text = dataBind.buttonconfirm!!.text.toString() + " Upload Res: " + (response.body?.string()
                                                ?: "")
                                        })

                                    }
                                }

                            )
                        }

                    }
                })
            })

        }

        dataBind.scan?.setOnClickListener {
            try {
                val intent = Intent("com.google.zxing.client.android.SCAN")
                intent.putExtra("SCAN_MODE", "QR_CODE_MODE") // "PRODUCT_MODE for bar codes
                startActivityForResult(intent, 0)
            } catch (e: Exception) {
                val marketUri: Uri =
                    Uri.parse("market://details?id=com.google.zxing.client.android")
                val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                startActivity(marketIntent)
            }
//            val options = BarcodeScannerOptions.Builder()
//                .setBarcodeFormats(
//                    Barcode.FORMAT_QR_CODE,
//                    Barcode.FORMAT_AZTEC)
//                .build()
//            startActivity(Intent(this@MainActivity, ScannedBarcodeActivity::class.java))
        }

        dataBind.contact1?.setOnClickListener {
            activity?.runOnUiThread(Runnable {
                // call the invalidate()
                dataBind.outlinedTextField1a?.setText("0")
                dataBind.outlinedTextField2a?.setText("NhQHRrgHhLQ74fR51N42X8LHr9EuX1fwzR")
                dataBind.outlinedTextField3a?.setText("Contact 1")
            })
        }
        dataBind.contact2?.setOnClickListener {
            activity?.runOnUiThread(Runnable {
                // call the invalidate()
                dataBind.outlinedTextField1a?.setText("0")
                dataBind.outlinedTextField2a?.setText("NhQHRrgHhLQ74fR51N42X8LHr9EuX1fwzR")
                dataBind.outlinedTextField3a?.setText("Contact 2")
            })
        }
        dataBind.contact3?.setOnClickListener {
            activity?.runOnUiThread(Runnable {
                // call the invalidate()
                dataBind.outlinedTextField1a?.setText("0")
                dataBind.outlinedTextField2a?.setText("NhQHRrgHhLQ74fR51N42X8LHr9EuX1fwzR")
                dataBind.outlinedTextField3a?.setText("Contact 3")
            })
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                val contents = data?.getStringExtra("SCAN_RESULT")
                var cnt = 0
                if (contents != null) {
                    for (c in contents) {
                        if (c == ',') {
                            cnt += 1
                        }
                    }
                }
                if (cnt == 2) {
                    // ADDR,AMOUNT,COMMENT
                    activity?.runOnUiThread(Runnable {
                        // call the invalidate()
//                        dataBind.scan!!.setText(contents)
                        val res = contents?.split(",")
                        val taddr = res?.get(0)
                        val tamount = res?.get(1)
                        val tcomment = res?.get(2)
                        activity?.runOnUiThread(Runnable {
                            // call the invalidate()
                            dataBind.outlinedTextField1a?.setText(tamount)
                            dataBind.outlinedTextField2a?.setText(taddr)
                            dataBind.outlinedTextField3a?.setText(tcomment)
                        })
                    })
                }
                else{
                    activity?.runOnUiThread(Runnable {
                        // call the invalidate()
                        dataBind.outlinedTextField1a?.setText("")
                        dataBind.outlinedTextField2a?.setText("")
                        dataBind.outlinedTextField3a?.setText("ERR")
                    })
                }
                if (resultCode == RESULT_CANCELED) {
                    //handle cancel
                }
            }
        }
    }

}
